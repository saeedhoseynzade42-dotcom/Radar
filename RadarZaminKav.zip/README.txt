نصب رادار زمین‌کاو (۴ مرحله)
1) github.com -> New repository -> اسم: radar -> Public -> Create
2) "uploading an existing file" -> همه ۵ فایل را انتخاب کن -> Commit changes
3) Settings -> Pages -> Branch: main / (root) -> Save
4) بعد از ۱ دقیقه در کروم اندروید باز کن: https://USERNAME.github.io/radar/
   منوی کروم (⋮) -> Install app / Add to Home screen
